import pygame
import copy
class BULLET:
    def __init__(self,player,w,h):
        self.w=w//2
        self.h=h//2
        self.player = player
        self.sprite=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/New Piskel (9).png").convert_alpha(),
            (20, 20)
        )
        self.rectangle=self.sprite.get_rect()
        self.imaginar_coords=copy.copy(self.player.imaginary_coords)
        self.coefficient=self.player.angle_shot()
        self.sprite_rect=self.sprite.get_rect()
        self.sprite_rect.x=self.imaginar_coords[0]
        self.sprite_rect.y =self.imaginar_coords[1]
    def Bullet_fly(self):
        self.imaginar_coords[0]+=self.coefficient[0]*4
        self.imaginar_coords[1] += self.coefficient[1]*4
        self.sprite_rect.x +=self.coefficient[0]*4
        self.sprite_rect.y += self.coefficient[1]*4
    def draw(self,screen):
        self.sprite_rect.x = self.imaginar_coords[0]-self.player.imaginary_coords[0]+self.w
        self.sprite_rect.y = self.imaginar_coords[1]-self.player.imaginary_coords[1]+self.h
        screen.blit(self.sprite, [self.sprite_rect.x,self.sprite_rect.y])
        self.Bullet_fly()
    def bullet_del(self):
        h=0
        g= [(self.imaginar_coords[0]-self.player.imaginary_coords[0]+self.w),self.imaginar_coords[1]-self.player.imaginary_coords[1]+self.h]
        if g[0]>1900 or g[0]<0:
            h=1
        elif g[1]>1060 or g[1]<0:
            h=1
        return h