import pygame
class heal_potion:
    def __init__(self,w,h,id):
        self.coords=[w,h]
        self.__heal_spr=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ITEMS/hp_potion.png").convert_alpha(),
            (115, 115))
        self.id=int(id)
    def draw(self, screen, coords):
        screen.blit(self.__heal_spr, coords)
    def activate(self):
        return ['heal',1,'del']
class axe:
    def __init__(self,w,h,dmg,id):
        self.coords = [w, h]
        self.id=id
        self.__axe_spr=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ITEMS/axe.png").convert_alpha(),
            (115, 115))
        self.dmg=dmg
    def swing(self):
        pass

