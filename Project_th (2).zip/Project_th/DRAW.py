import pygame
print()
class Draw:
    def __init__(self,w,h,map,player):
        self.__coords=[w,h]
        self.__map=map
        self.__player=player
        self.saving=False
        self.battle_or_peace=1
        """ПОДСЧЕТ ПЕРЕКЛЮЧЕНИЙ ЛОГИКИ/СОСТОЯНИЯ"""
    def draw(self,screen):
        screen.blit(self.__map.maps[self.__map.map_cnts],
                    [self.__player.imaginary_coords[0] * -1, self.__player.imaginary_coords[1] * -1])
        for i in self.__map.map_objects_water[self.__map.map_cnts]:
            i.draw(screen)
        for i in self.__map.map_objects[self.__map.map_cnts]:
            i.check()
            i.collide()
            collision=self.__player.cut()
            if collision[0]:
                item=i.hit_collide(collision[1])
                if item[0]:
                    if item[1]=='save':
                        self.saving=True
                    if item[1]=='BOSS_BATTLE':
                        self.battle_or_peace=2
            if i.y_cord<=self.__player.player_rect.centery:
                i.draw(screen)
        self.__player.draw(screen)
        self.__map.draw(screen)
        for i in self.__map.map_objects[self.__map.map_cnts]:
            i.check()
            if i.y_cord>=self.__player.player_rect.centery:
                i.draw(screen)
    def returning(self):
        return self.saving
class DRAW_BATTLE:
    def __init__(self,w,h,map,player,enemy):
        self.__enemy=enemy
        self.attack_list=[]
        self.__font = pygame.font.Font('PRoject2/ARCADECLASSIC.TTF', 64)
        self.score=2100
        """СПИСОКdda АТТАК"""
        self.enemy_attack_list=[]
        """СПИСОК АТТАК СОПЕРНИКА"""
        self.movement_list=[[],[],[]]
        """СПИСОК ДВИЖЕНИЙ"""
        multiply=h/448
        multiply= round(multiply,2)
        """СОЗДАНИЕ МНОЖИТЕЛЯ ДЛЯ СПРАЙТА"""
        self.__sprite = [pygame.transform.smoothscale(
            pygame.image.load("PRoject2/Th128SpringPathSt2.jpg").convert(),
            (384*multiply,h))]
        self.__multiplyer=384*multiply
        self.__coords=[w,h]
        self.__map=map
        self.__player=player
        self.counting=0
        """Подсчет кадров"""
        self.game=True
        self.__surface=pygame.Surface([384*multiply,h])
        self.__cord_x = self.__coords[0] // 2 - (384 * multiply // 2)
    def draw(self,screen):
        text=str(int(self.score))
        text1 = self.__font.render(text, True,
                                   (255, 255, 255))
        self.__surface.blit(self.__sprite[0],[0,0])
        self.__enemy.draw(self.__surface)
        if self.game:
            self.game= not(pygame.Rect.colliderect(self.__player.sprite_rect, self.__enemy.sprite_rect))
        for i in self.attack_list:
            i.draw(self.__surface)
        self.__player.draw(self.__surface)
        for i in self.enemy_attack_list[0:self.counting//120]:
            for j in i:
                j.move()
                j.draw(self.__surface)
                if self.game:
                    self.game=not(j.collide(self.__player))
        for i in self.movement_list[0:self.counting//120]:
            for j in i:
                j.move()
        screen.blit(self.__surface,[self.__cord_x,0])
        screen.blit(text1, [self.__cord_x+self.__multiplyer+40, 100])
        self.counting+=1
        if self.counting>360:
            self.counting=360
        if len(self.enemy_attack_list[-1])==0:
            self.counting=0
            self.movement_list=[[],[],[]]
            self.enemy_attack_list=[[],[],[]]
        self.score-=1
        for i in self.enemy_attack_list[0:self.counting//120]:
            for j in i:
                if j.delete:
                    i.remove(j)
