import pygame
from math import atan2, degrees, pi
from random import randint
class ENEMY_MOVE:
    def __init__(self, enemy,lenx,leny,speed,dir: list):
        self.__enemy = enemy
        self.__lenx=lenx
        self.__leny=leny
        self.__speed=speed
        self.__dir=dir
    def move(self):
        if self.__lenx>0:
            self.__lenx-=self.__speed
            self.__enemy.sprite_rect.x+=(self.__speed)*self.__dir[0]
            if self.__dir[0]>0:
                self.__enemy.sprite_move = 1
            else:
                self.__enemy.sprite_move = 0
        if self.__leny>0:
            self.__leny-=self.__speed
            self.__enemy.sprite_rect.y+=(self.__speed)*self.__dir[1]

class ENEMY:
    def __init__(self,w,h,player,x,y):
        self.__x=x
        self.__y=y
        self.coords=[w,h]
        self.__sprite=[[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/cirno/tile000.png").convert_alpha(),
            (126, 120)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/cirno/tile002.png").convert_alpha(),
            (126, 120)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/cirno/tile004.png").convert_alpha(),
            (126, 120))],

            [pygame.transform.smoothscale(
            pygame.image.load("PRoject2/cirno/tile026.png").convert_alpha(),
            (126, 120)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/cirno/tile028.png").convert_alpha(),
            (126, 120)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/cirno/tile030.png").convert_alpha(),
            (126, 120))]]
        self.sprite_rect=self.__sprite[0][0].get_rect()
        self.sprite_rect.x=x
        self.hp=899
        self.sprite_rect.y=y
        self.player=player
        self.win=False
        self.__sprite_count=0
        self.sprite_move=0
        self.sprite_rect.x = self.__x
        self.sprite_rect.y = self.__y
    def __anim(self):
        self.__sprite_count+=1
        self.__sprite_count%=24
    def attack(self):
        pass
    def draw(self,screen):
        self.check_if_lose()
        self.__anim()
        pi=3.14
        screen.blit(self.__sprite[self.sprite_move][self.__sprite_count//8], self.sprite_rect)
        pygame.draw.arc(screen, [255,255,255],
                        (self.sprite_rect.x-40, self.sprite_rect.y-10, 156, 156), 0, self.hp/900 * pi*2, 3)
    def check_if_lose(self):
        if self.hp<1:
            self.win=True
class attack_simple:
    def __init__(self,h,player,enemy,x,y):
        self.__player=player
        self.__height=h
        self.__enemy=enemy
        self.__sprite=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/attacks/ice_shot.png").convert_alpha(),
            (126, 342))
        self.__cord=self.angle_shot(self.__enemy.sprite_rect.centerx+x,self.__enemy.sprite_rect.centery+y)
        self.__rect=self.__sprite.get_rect()
        self.__sprite = pygame.transform.scale(self.__sprite, ((self.__rect.width//10, self.__rect.height//10)))
        self.__rect = self.__sprite.get_rect()
        self.__colliderect=pygame.rect.Rect(self.__rect.centerx-5,self.__rect.centery-5,14,14)
        self.__rect.x= self.__enemy.sprite_rect.centerx+x-40
        self.__rect.y =self.__enemy.sprite_rect.centery+y
        self.delete = False
    def angle_shot(self,x,y):
        dx = x-self.__enemy.sprite_rect.centerx
        dy = y-self.__enemy.sprite_rect.centery
        rads = atan2(-dy, dx)
        rads %= 2 * pi
        degs = degrees(rads)
        degs=int(degs)
        self.__sprite=pygame.transform.rotate(self.__sprite, -(90-degs))
        self.cooldown=500
        cord=[1,1]
        if degs<=90:
            cord[0]=abs((90 - degs) / 45)
            cord[1]=abs(90 - (cord[0] * 45))
            cord[1]=round(cord[1]/90,4)*-1
            cord[0]=round(cord[0]/2,4)
        elif degs<=180:
            degs-=90
            cord[1] = abs((90 - degs) / 45)
            cord[0] = abs(90 - (cord[1] * 45))
            cord[0] = round(cord[0] / 90, 4)*-1
            cord[1] = round(cord[1] / 2, 4)*-1
        elif degs<=270:
            degs-=180
            cord[0] = abs((90 - degs) / 45)
            cord[1] = abs(90 - (cord[0] * 45))
            cord[1] = round(cord[1] / 90, 4)
            cord[0] = round(cord[0] / 2, 4)*-1
        else:
            degs-=270
            cord[1] = abs((90 - degs) / 45)
            cord[0] = abs(90 - (cord[1] * 45))
            cord[0] = round(cord[0] / 90, 4)
            cord[1] = round(cord[1] / 2, 4)
        return cord
    def draw(self,surf):
        surf.blit(self.__sprite,self.__rect)
    def collide(self,player):
        x, y = player.sprite.centerx,player.sprite.centery
        if (self.__colliderect[0] < x and x < self.__colliderect[0]+self.__colliderect[2]):
            if (self.__colliderect[1] < y and y < self.__colliderect[1]+self.__colliderect[3]):
                return True
    def move(self):
        self.__rect.y+=self.__cord[1]*6
        self.__rect.x +=self.__cord[0]*6
        self.__colliderect.x=self.__rect.centerx-7
        self.__colliderect.y=self.__rect.centery-7
        if self.__rect.y<0:
            self.delete=True
        elif self.__rect.y>self.__height:
            self.delete=True
        if self.__rect.x < 0:
            self.delete = True
        elif self.__rect.x > 1920:
            self.delete = True
class card_reimu:
    def __init__(self,h,player):
        self.__player=player
        self.__height=h
        self.__sprite=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu_fight/card.png").convert_alpha(),
            (24, 36))
        self.__sprite.set_alpha(200)
        self.__rect=self.__sprite.get_rect()
        self.__rect.x=self.__player.sprite.centerx
        self.__rect.y = self.__player.sprite.y
        self.delete=False
        self.__alpha=200-(self.__player.sprite_rect.y-self.__rect.y)//5.4
    def draw(self,surf):
        self.__alpha=200-(self.__player.sprite_rect.y-self.__rect.y)//5.4
        self.__sprite.set_alpha(self.__alpha)
        surf.blit(self.__sprite,self.__rect)
    def collide(self,enemy):
        if pygame.Rect.colliderect(enemy, self.__rect):
            self.delete=True
            return 2
        else:
            return 0
    def move(self):
        self.__rect.y-=15
        if self.__rect.y<0:
            self.delete=True
            self.__player.miss+=1
class Battle_reimu:
    def __init__(self, w, h, player):
        self.coords = [w, h]
        self.miss=0
        multiply = h / 448
        multiply = round(multiply, 2)
        multiply=384*multiply
        self.__border_x=multiply
        self.__mouseplus=(w-multiply)//2
        self.__sprite_reimu = [pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu_fight/tile000.png").convert_alpha(),
            (62, 96)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu_fight/tile001.png").convert_alpha(),
            (62, 96)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu_fight/tile002.png").convert_alpha(),
            (62, 96)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu_fight/tile003.png").convert_alpha(),
            (62, 96)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu_fight/tile004.png").convert_alpha(),
            (62, 96)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu_fight/tile005.png").convert_alpha(),
            (62, 96)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu_fight/tile006.png").convert_alpha(),
            (62, 96))]
        self.__heart=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/attacks/tile001.png").convert_alpha(),
            (8, 8))
        """СПРАЙТ ДЛЯ БОЯ"""
        self.sprite_rect = self.__sprite_reimu[0].get_rect()
        self.sprite=self.__sprite_reimu[0].get_rect()
        self.__sprite_count=0
        self.__player = player
    def __anim(self):
        self.__sprite_count+=1
        self.__sprite_count%=30
    def draw(self,surf):
        self.__anim()
        cords=pygame.mouse.get_pos()
        self.sprite_rect.x=cords[0]-self.__mouseplus-self.__sprite_count//5*2-31
        self.sprite_rect.y =cords[1]-48
        if self.sprite_rect.x<0:
            self.sprite_rect.x=0
        if self.sprite_rect.x>self.__border_x-62:
            self.sprite_rect.x=self.__border_x-62
        cords=[self.sprite_rect.x+self.__sprite_count//5*2,self.sprite_rect.y]
        self.sprite.x = cords[0]
        self.sprite.y = cords[1]
        surf.blit(self.__sprite_reimu[self.__sprite_count//5],self.sprite_rect)
        surf.blit(self.__heart,[self.sprite.x+self.sprite.width//2-6,self.sprite.y+self.sprite.height//2-4])
class attack_ball:
    def __init__(self,h,player,enemy,speed_up,speed,delay):
        self.__player=player
        self.__height=h
        self.__delay=delay
        self.__divider=4
        self.__counting=0
        """Подсчет кадров"""
        self.__speed_up=speed_up
        """УСКОРЕНИЕ"""
        self.__speed = speed
        """СКОРОСТЬ"""
        self.__enemy=enemy
        self.__count=randint(1,6)
        if self.__count==1:
            self.__sprite=pygame.transform.smoothscale(
                pygame.image.load("PRoject2/attacks/tile002.png").convert_alpha(),
                (32, 32))
        elif self.__count==2:
            self.__sprite=pygame.transform.smoothscale(
                pygame.image.load("PRoject2/attacks/tile003.png").convert_alpha(),
                (32, 32))
        elif self.__count==3:
            self.__sprite=pygame.transform.smoothscale(
                pygame.image.load("PRoject2/attacks/tile004.png").convert_alpha(),
                (32, 32))
        elif self.__count==4:
            self.__sprite=pygame.transform.smoothscale(
                pygame.image.load("PRoject2/attacks/tile005.png").convert_alpha(),
                (32, 32))
        else:
            self.__sprite = pygame.transform.smoothscale(
                pygame.image.load("PRoject2/attacks/tile006.png").convert_alpha(),
                (32, 32))
        self.__rect=self.__sprite.get_rect()
        self.__colliderect=pygame.rect.Rect(self.__rect.centerx-12,self.__rect.y+3,24,26)
        self.__rect.x= self.__enemy.sprite_rect.centerx
        self.__rect.y =self.__enemy.sprite_rect.centery
        self.delete = False
    def draw(self,surf):
        if self.__delay<1:
            surf.blit(self.__sprite,self.__rect)
        self.__delay-=1
    def collide(self,player):
        x, y = player.sprite.centerx,player.sprite.centery
        if (self.__colliderect[0] < x and x < self.__colliderect[0]+self.__colliderect[2]):
            if (self.__colliderect[1] < y and y < self.__colliderect[1]+self.__colliderect[3]):
                return True
    def move(self):
        self.__counting+=1
        if self.__delay==0:
            self.__rect.x = self.__enemy.sprite_rect.centerx
            self.__rect.y = self.__enemy.sprite_rect.centery
        elif self.__delay<1:
            if self.__counting % int(self.__divider) == 0:
                self.__rect.x+=self.__speed[0]+self.__counting/90
            self.__rect.y += self.__speed[1]
            self.__colliderect.x=self.__rect.centerx-12
            self.__colliderect.y=self.__rect.y+3
            if self.__rect.y<0:
                self.delete=True
            elif self.__rect.y>self.__height:
                self.delete=True
            if self.__rect.x < 0:
                self.delete = True
            elif self.__rect.x > 1920:
                self.delete = True
            if self.__divider>1.5:
                self.__divider -= self.__speed_up
        if self.__counting>120:
            self.__counting=119

