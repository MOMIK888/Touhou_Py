import requests
import pygame
import time
import PLAYER
import MAP
import DRAW
import BULLET
import save
import ENEMY
from math import atan2, degrees, pi
class Game:
    def __init__(self, width=1920, height=1080, fps=60):
        pygame.init()
        self.__game_end=False
        self.__width=width
        self.__height=height
        self.__font = pygame.font.Font('PRoject2/ARCADECLASSIC.TTF', 64)
        self.bullet_lengh=0
        self.bullets=[]
        self.__screen = pygame.display.set_mode((self.__width, self.__height), pygame.FULLSCREEN)
        self.__save = save.save(width, height)
        self.__player = PLAYER.player(self.__width, self.__height)
        self.beaten_bosses=''
        self.__attacks=[]
        self.wait = False
        self.__fps = fps
        self.__clock = pygame.time.Clock()
        self.__map=MAP.map(self.__width, self.__height,self.__player,self.bullets)
        self.drawing=DRAW.Draw(width,height,self.__map,self.__player)
        """ОТРИСОВКА"""
        self.__battle_reimu=ENEMY.Battle_reimu(self.__width, self.__height,self.__player)
        self.__enemy=ENEMY.ENEMY(self.__width, self.__height,self.__player,200,200)
        self.drawing2 = DRAW.DRAW_BATTLE(width, height, self.__map, self.__battle_reimu,self.__enemy)
        """ОТРИСОВКА ВО ВРЕМЯ БОЯ"""
        self.time=0
        pygame.mixer.music.load("PRoject2/videoplayback (2).mp3")
        self.__check_chicking=False
        self.__returning=False
        self.__load_save()
        self.__change_pos()
        self.drawing2.enemy_attack_list=[[],[],[]]
        """СПИСОК АТТАК ВРAГА"""
        self.__movement_list=[[],[],[]]
        self.__fill_attack_list()
    def waiting(self):
        if self.wait==False:
            pygame.mixer.music.play(-1)
            self.wait=True
    def run(self):
        while not self.__game_end:
            self.__check_events()
            if self.__enemy.win:
                self.__screen.fill([0,0,0])
                text1 = self.__font.render(str(self.drawing2.score), True,
                                           (255, 255, 255))
                self.__screen.blit(text1, [self.__width // 2 - 16 * len(str(self.drawing2.score))-8*16, self.__height // 2])
                if self.drawing2.score>1100:
                    text1 = self.__font.render('rank  S', True,
                                               (255, 255, 255))
                    self.__screen.blit(text1, [self.__width // 2 - len(str(self.drawing2.score)), self.__height // 2])
                elif self.drawing2.score>900:
                    text1 = self.__font.render('rank  A', True,
                                               (255, 255, 255))
                    self.__screen.blit(text1, [self.__width // 2 - len(str(self.drawing2.score)), self.__height // 2])
                elif self.drawing2.score>500:
                    text1 = self.__font.render('rank  B', True,
                                               (255, 255, 255))
                    self.__screen.blit(text1, [self.__width // 2 - len(str(self.drawing2.score)), self.__height // 2])
                else:
                    text1 = self.__font.render('rank  D', True,
                                               (255, 255, 255))
                    self.__screen.blit(text1, [self.__width // 2 - len(str(self.drawing2.score)), self.__height // 2])
            elif self.drawing.battle_or_peace==1 and self.drawing2.game:
                self.__move_objects()
                self.__draw()
                pygame.mouse.set_visible(True)
                self.__logic()
            elif self.drawing.battle_or_peace==2 and self.drawing2.game:
                self.__draw2()
                pygame.mouse.set_visible(False)
                self.__attack()
                self.waiting()
            elif not(self.drawing2.game) and not(self.__enemy.win):
                self.__screen.fill([0,0,0])
                text1 = self.__font.render('GAME OVER', True,
                                           (255, 255, 255))
                self.__screen.blit(text1,[self.__width//2-16*9,self.__height//2])
            self.__flip()
            self.__clock.tick(self.__fps)
    def __flip(self):
        pygame.display.flip()
        self.time+=1
        self.time%=10
    def __check_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.__game_end = True
            if self.drawing.battle_or_peace==1:
                self.__player.check_event(event)
            else:
                pass
        if self.drawing.battle_or_peace == 1:
            self.__save.check_events()
    def __move_objects(self):
        self.__player.move()
    def __attack(self):
        if self.time%2==0:
            self.__attacks.append(ENEMY.card_reimu(self.__height,self.__battle_reimu))
        for i in self.__attacks:
            i.move()
            s=i.collide(self.__enemy.sprite_rect)
            self.__enemy.hp-=s
        for i in self.__attacks:
            if i.delete:
                self.__attacks.remove(i)
    def __draw(self):
        self.__screen.fill([0,0,0])
        self.drawing.draw(self.__screen)
        for i in range(self.bullet_lengh,len(self.bullets)):
            self.bullets[i].draw(self.__screen)
        if len(self.bullets)-self.bullet_lengh>0:
            self.bullet_lengh+=self.bullets[self.bullet_lengh].bullet_del()
        self.__map.bullets=self.bullets[self.bullet_lengh::]
        self.__player.draw_inventory(self.__screen)
        if self.drawing.returning():
            self.__save.draw(self.__screen, self.drawing.returning())
        if self.__save.check:
            self.__save.blinking()
            if self.__save.check==False:
                self.drawing.saving=False
                self.__check_chicking=True
    def __draw2(self):
        self.__screen.fill([0, 0, 0])
        self.drawing2.attack_list=self.__attacks
        self.drawing2.draw(self.__screen)
        if self.drawing2.counting==0:
            self.__fill_attack_list()
    def __change_pos(self):
        self.__map.change_pos()
    def __load_save(self):
        save=self.__save.load_save()
        temp = save
        temp = temp[0]
        temp = list(temp)
        temp[6] = temp[6].replace("[", '')
        temp[6] = temp[6].replace("]", '')
        temp[6] = temp[6].split(', ')
        for i in range(len(temp[6])):
            temp[6][i] = int(temp[6][i])
        self.__player.name = temp[1]
        self.__player.money = int(temp[2])
        self.__player.hp = int(temp[3])
        self.__map.imagination_coords[int(temp[6][2])] = [int(temp[6][0]), int(temp[6][1])]
    def __logic(self):
        if self.__check_chicking:
            self.__save.saving(self.__player.name, self.__player.money, self.__player.hp, self.beaten_bosses,
                               self.time, [self.__map.imagination_coords[self.__map.map_cnts], self.__map.map_cnts])
            self.__check_chicking=False

    def angle_shot(self,x,y):
        dx = x - self.__enemy.sprite_rect.centerx
        dy = y - self.__enemy.sprite_rect.centery
        rads = atan2(-dy, dx)
        rads %= 2 * pi
        degs = degrees(rads)
        degs=int(degs)
        cord=[1,1]
        if degs<=90:
            cord[0]=abs((90 - degs) / 45)
            cord[1]=abs(90 - (cord[0] * 45))
            cord[1]=round(cord[1]/90,4)*-1
            cord[0]=round(cord[0]/2,4)
        elif degs<=180:
            degs-=90
            cord[1] = abs((90 - degs) / 45)
            cord[0] = abs(90 - (cord[1] * 45))
            cord[0] = round(cord[0] / 90, 4)*-1
            cord[1] = round(cord[1] / 2, 4)*-1
        elif degs<=270:
            degs-=180
            cord[0] = abs((90 - degs) / 45)
            cord[1] = abs(90 - (cord[0] * 45))
            cord[1] = round(cord[1] / 90, 4)
            cord[0] = round(cord[0] / 2, 4)*-1
        else:
            degs-=270
            cord[1] = abs((90 - degs) / 45)
            cord[0] = abs(90 - (cord[1] * 45))
            cord[0] = round(cord[0] / 90, 4)
            cord[1] = round(cord[1] / 2, 4)
        return cord
    def __fill_attack_list(self):
        self.drawing2.movement_list[0].append(ENEMY.ENEMY_MOVE(self.__enemy, 100, 0, 8, [-1, 1]))
        for i in range(41):
            degs=i*9
            cord = [1, 1]
            if degs <= 90:
                cord[0] = abs((90 - degs) / 45)
                cord[1] = abs(90 - (cord[0] * 45))
                cord[1] = round(cord[1] / 90, 4) * -1
                cord[0] = round(cord[0] / 2, 4)
            elif degs <= 180:
                degs -= 90
                cord[1] = abs((90 - degs) / 45)
                cord[0] = abs(90 - (cord[1] * 45))
                cord[0] = round(cord[0] / 90, 4) * -1
                cord[1] = round(cord[1] / 2, 4) * -1
            elif degs <= 270:
                degs -= 180
                cord[0] = abs((90 - degs) / 45)
                cord[1] = abs(90 - (cord[0] * 45))
                cord[1] = round(cord[1] / 90, 4)
                cord[0] = round(cord[0] / 2, 4) * -1
            else:
                degs -= 270
                cord[1] = abs((90 - degs) / 45)
                cord[0] = abs(90 - (cord[1] * 45))
                cord[0] = round(cord[0] / 90, 4)
                cord[1] = round(cord[1] / 2, 4)
            self.drawing2.enemy_attack_list[0].append(ENEMY.attack_simple(self.__height,self.__battle_reimu,self.__enemy, cord[0]*50,cord[1]*50))
        for i in range(21):
            self.drawing2.enemy_attack_list[1].append(
                ENEMY.attack_ball(self.__height, self.__battle_reimu, self.__enemy, 0.005, [1*(i/3),4],i*5))
            self.drawing2.enemy_attack_list[1].append(
                ENEMY.attack_ball(self.__height, self.__battle_reimu, self.__enemy, 0.005, [-1 * (i / 3), 3], i * 6))
        for i in range(21):
            self.drawing2.enemy_attack_list[2].append(
                ENEMY.attack_ball(self.__height, self.__battle_reimu, self.__enemy, 0.003, [1*(i/2),6],i*7))
        for i in range(21):
            self.drawing2.enemy_attack_list[2].append(
                ENEMY.attack_ball(self.__height, self.__battle_reimu, self.__enemy, 0.003, [1*(i/2),6],i))
        for i in range(21):
            self.drawing2.enemy_attack_list[2].append(
                ENEMY.attack_ball(self.__height, self.__battle_reimu, self.__enemy, 0.005, [1*(i/3),6],i*8))
            self.drawing2.enemy_attack_list[2].append(
                ENEMY.attack_ball(self.__height, self.__battle_reimu, self.__enemy, 0.005, [-1 * (i / 3), 4.5], i * 7))
        self.drawing2.movement_list[0].append(ENEMY.ENEMY_MOVE(self.__enemy,400,0,2,[1,1]))
        self.drawing2.movement_list[2].append(ENEMY.ENEMY_MOVE(self.__enemy, 400, 0, 2, [-1, 1]))
def main():
    game = Game()
    game.run()


main()
