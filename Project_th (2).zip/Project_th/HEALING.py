import pygame
class heal_potion:
    def __init__(self,w,h):
        self.coords=[w,h]
        self.__heal_spr=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ITEMS/hp_potion.png").convert_alpha(),
            (115, 115))
    def draw(self, screen, coords):
        screen.blit(self.__heal_spr, coords)
