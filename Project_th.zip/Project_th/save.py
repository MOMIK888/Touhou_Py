import sqlite3
import pygame
class save:
    def __init__(self, w, h):
        self.__coords=[w,h]
        self.__sprites=[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ICONS/save.png").convert(),
            (256*2,173*2)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ICONS/save_activated.png").convert(),
            (256*2,2*173))]
        self.__rect=self.__sprites[0].get_rect()
        self.__rect.x=w//2-128*2
        self.__rect.y = h // 2 - 86*2
        self.__count = 0
        self.coundown=0
        """ОТСЧЕТ"""
        self.__eq=False
        self.check=False
        self.__colliderect=pygame.rect.Rect(self.__rect.x+12,self.__rect.bottom-13,104,36)
    def load_save(self):
        with sqlite3.connect("PRoject2/DBS/saves.db") as connection:
            my_cursour = connection.cursor()
            query = "SELECT * FROM saves WHERE id=(SELECT max(id) FROM saves)"
            my_cursour.execute(query)
            rows = my_cursour.fetchall()
            return rows
    def saving(self,name,money,hp,beaten_bosses,time,place):
        with sqlite3.connect("PRoject2/DBS/saves.db") as connection:
            my_cursour = connection.cursor()
            query = f"INSERT INTO saves(name,money,hp,beaten_bosses,time_time,place) VALUES ('{name}','{money}','{hp}','{beaten_bosses}','{time}','{place}')"
            my_cursour.execute(query)
    def clear(self):
        with sqlite3.connect("PRoject2/DBS/saves.db") as connection:
            my_cursour = connection.cursor()
            query = "DELETE FROM saves WHERE 1=1"
            my_cursour.execute(query)
    def check_events(self):
        if pygame.mouse.get_pressed()[0]:
            mouse = pygame.mouse.get_pos()
            mouse = pygame.Rect(mouse[0], mouse[1], 1, 1)
            if pygame.Rect.colliderect(mouse,self.__rect) and self.__count<1:
                self.__count=40
                self.check=True
                self.coundown=10
    def draw(self, screen, check):
        if check:
            screen.blit(self.__sprites[self.__eq*1],self.__rect)
    def blinking(self):
        if self.__count > 0 and self.coundown<1:
            if self.__count % 8 == 0:
                self.__eq = not (self.__eq)
            self.__count -= 1
            if self.__count==0:
                self.check=False
        self.coundown//=1.1

