import pygame
from math import atan2, degrees, pi
import os
import sqlite3
import ITEMS
import copy
class player:
    def __init__(self,w,h):
        self.coords=[w//2,h//2]
        self.time=0
        self.name='default'
        self.__x=w//2
        self.__y=h//2
        self.cooldown=0
        self.count_for_anim=[10,0]
        self.bullets=[]
        self.money=0
        self.cndown=0
        self.__font=pygame.font.Font('PRoject2/ARCADECLASSIC.TTF',64)
        self.__effect_slash=[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/EFFECT/SLASH.png").convert_alpha(),
            (120, 35)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/EFFECT/SLASH.png").convert_alpha(),
            (120, 35)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/EFFECT/SLASH.png").convert_alpha(),
            (120, 35)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/EFFECT/SLASH.png").convert_alpha(),
            (120, 35))]
        self.__effect_slash[1]=pygame.transform.rotate(self.__effect_slash[1],180)
        self.__effect_slash[2] = pygame.transform.rotate(self.__effect_slash[2],270)
        self.__effect_slash[3] = pygame.transform.rotate(self.__effect_slash[3],90)
        self.__effect_slash[0].set_alpha(200)
        self.__effect_slash[1].set_alpha(200)
        self.__effect_slash[2].set_alpha(200)
        self.__effect_slash[3].set_alpha(200)
        """ЭФФЕКТ РАЗРЕЗА"""
        self.__test_img=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/New Piskel (9).png").convert_alpha(),
            (115, 115))
        self.__icons=[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ICONS/attack_icon.png").convert_alpha(),
            (160, 60)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ICONS/def_icon.png").convert_alpha(),
            (160, 60)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ICONS/spd_icon.png").convert_alpha(),
            (160, 60)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ITEMS/coin.png").convert_alpha(),
            (64, 64))]
        self.inventory=False
        self.ggggg=True
        self.drawing_line=False
        self.__buttons=[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/backpack/equip.png").convert_alpha(),
            (256, 87)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/backpack/equip_activate.png").convert_alpha(),
            (256, 87))]
        self.__backpack_spr=[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/backpack/New Piskel (10).png").convert_alpha(),
            (124, 124)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/backpack/INVENTORY.png").convert_alpha(),
            (1920, 1080)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/backpack/weapon_slot.png").convert_alpha(),
            (256, 256)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/backpack/armor_slot.png").convert_alpha(),
            (256, 256))]
        self.__player_sprites=[[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile000.png").convert_alpha(),
            (68, 124)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile001.png").convert_alpha(),
            (68, 124)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile002.png").convert_alpha(),
            (68, 124)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile003.png").convert_alpha(),
            (68, 124))],

            [pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile008.png").convert_alpha(),
            (68, 124)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile009.png").convert_alpha(),
            (68, 124)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile010.png").convert_alpha(),
            (68, 124)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile011.png").convert_alpha(),
            (68, 124))],

            [pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile016.png").convert_alpha(),
            (68, 124)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile017.png").convert_alpha(),
            (68, 124)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile018.png").convert_alpha(),
            (68, 124)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile019.png").convert_alpha(),
            (68, 124))],

            [pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile024.png").convert_alpha(),
            (68, 124)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile025.png").convert_alpha(),
            (68, 124)), pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile026.png").convert_alpha(),
            (68, 124)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/reimu/tile027.png").convert_alpha(),
            (68, 124))]]
        """СПРАЙТЫ 0-W, 1-"""
        self.__equip_rect=self.__buttons[0].get_rect()
        self.__equip_rect.x, self.__equip_rect.y=self.__x, self.__y*1.6
        self.head_spr_cnt=0
        self.hp=3
        self.player_rect=self.__player_sprites[0][0].get_rect()
        self.player_rect.x=self.__x-self.player_rect.topright[0]/2
        self.player_rect.y=self.__y-self.player_rect.bottomright[1]/2
        self.default=[self.player_rect.x, self.player_rect.y]
        self.__hp_spr=[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/New Piskel (10).png").convert_alpha(),
            (78*3,24*3)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/New Piskel (11).png").convert_alpha(),
            (17*3.5,8*3.5)) ]
        self.imaginary_coords=[0,0]
        """ВООБРАЖАЕМЫЕ КООРДИНАТЫ ДЛЯ ОТРИСОВКИ"""
        self.plus_running=0
        self.backpack_slots=6
        self.y_cord=self.player_rect.centery
        self.facing=[False,False,True,False]
        self.__slash_info=[0,0,80,0,100]
        """информация ра разрезе"""
        self.speed=3
        self.__direction_true={pygame.K_w: False, pygame.K_a: False, pygame.K_s: False, pygame.K_d: False,
                            pygame.K_SPACE: False, pygame.K_c: False}
        self.__direction = {pygame.K_w: False, pygame.K_a: False, pygame.K_s: False, pygame.K_d: False,
                            pygame.K_SPACE: False, pygame.K_c: False}
        self.backpack_items=[]
        self.inv_slot=False
        self.__counting=0
        """ПОДСЧЕТ КАДРОВ ДЛЯ АНИМАЦИЙ"""
        self.__count=0
        """ДЛЯ ПОДСЧЕТА КНОПКИ ИНВЕНТАРЯ(МЕРЦАНИЕ)"""
        self.slot_light=-100
        self.blocking_movement=[1,1,1,1]
        self.__eq=False
        self.clear_inventory()
        self.backpack_append('heal_potion')
        with sqlite3.connect("PRoject2/DBS/BACKPACK/backpack.db") as connection:
            self.backpack_items=[]
            my_cursour = connection.cursor()
            query = "SELECT * FROM backpack"
            my_cursour.execute(query)
            rows = my_cursour.fetchall()
            for i in rows:
                self.backpack_items.append(i)
            for i in range(len(self.backpack_items)):
                if self.backpack_items[i][1]=="heal_potion":
                    self.backpack_items[i]=(ITEMS.heal_potion(self.__x, self.__y,self.backpack_items[i][0]))
            print(self.backpack_items)
        self.__backpack_rect=self.__backpack_spr[0].get_rect()
    def clear_inventory(self):
        with sqlite3.connect("PRoject2/DBS/BACKPACK/backpack.db") as connection:
            my_cursour = connection.cursor()
            query = "DELETE FROM backpack WHERE 1=1"
            my_cursour.execute(query)
    def check_event(self, event):
        if pygame.mouse.get_pressed()[0]:
            if self.cndown==0:
                self.cndown=30
                self.slash()
            if self.inventory:
                mouse = pygame.mouse.get_pos()
                mouse = pygame.Rect(mouse[0], mouse[1], 1, 1)
                for i in range(self.backpack_slots):
                    rect=self.__backpack_spr[0].get_rect()
                    rect.x,rect.y=100 + 130 * (i % 5), self.__y + (i // 5 * 130)
                    if pygame.Rect.colliderect(mouse,rect):
                        self.slot_light=i
                if pygame.Rect.colliderect(mouse,self.__equip_rect) and self.__count<1:
                    self.__eq=True
                    self.activate_or_equip()
                    self.__count=20
            else:
                self.slot_light=-100
        if event.type == pygame.KEYDOWN:
            self.__direction[event.key]=True
            if event.key==pygame.K_c:
                self.inventory=not(self.inventory)
                if not(self.inventory):
                    self.slot_light=-100
        elif event.type == pygame.KEYUP:
            self.__direction[event.key] = False
        if self.cndown>0:
            self.cndown-=1
    def cut(self):
        if self.__slash_info[3]>0:
            l=self.__effect_slash[self.__slash_info[0]].get_rect()
            l.x = self.player_rect.centerx + self.__slash_info[1]
            l.y = self.player_rect.centery + self.__slash_info[2]
            return [True, l]
        else:
            return [False]
    def slicing(self,screen):
        if self.__slash_info[3]>0:
            self.__effect_slash[self.__slash_info[0]].set_alpha(self.__slash_info[3])
            screen.blit(self.__effect_slash[self.__slash_info[0]],[self.player_rect.centerx+self.__slash_info[1],self.player_rect.centery
                                                                   + self.__slash_info[2]])
            self.__slash_info[4]-=18
            if self.__slash_info[4]>0:
                self.__slash_info[3]+=18
            else:
                self.__slash_info[3]-=18
    def delete(self,db,id):
        if self.is_database_exists("PRoject2/DBS/BACKPACK/backpack.db"):
            with sqlite3.connect("PRoject2/DBS/BACKPACK/backpack.db") as connection:
                my_cursour = connection.cursor()
                query = f"DELETE FROM {db} WHERE id_author = {id}"
                my_cursour.execute(query)
                self.backpack_items = []
                query = "SELECT * FROM backpack"
                my_cursour.execute(query)
                rows = my_cursour.fetchall()
                self.backpack_items=[]
                for i in rows:
                    self.backpack_items.append(i)
                for i in range(len(self.backpack_items)):
                    if self.backpack_items[i][1] == "heal_potion":
                        self.backpack_items[i] = (ITEMS.heal_potion(self.__x, self.__y, self.backpack_items[i][0]))
    def __show_xp(self,screen):
        for i in range(self.hp):
            screen.blit(self.__hp_spr[1], [220-62*i, 73])
        screen.blit(self.__hp_spr[0],[50,50])
    def is_database_exists(self,path):
        return os.path.exists(path)
    def slash(self):
        if self.facing[2]:
            self.__slash_info=[0,-60,40,80,100]
        elif self.facing[0]:
            self.__slash_info=[1,-60,-90,80,100]
        elif self.facing[3]:
            self.__slash_info=[2,-80,-18,80,100]
        else:
            self.__slash_info=[3,40,-18,80,100]
    def activate_or_equip(self):
        if len(self.backpack_items)-1>=self.slot_light and self.slot_light>=0:
            a=self.backpack_items[self.slot_light].activate()
            if a[0]=='heal':
                self.hp+=a[1]
                if self.hp>3:
                    self.hp=3
            if a[-1]=='del':
                self.delete('backpack',self.backpack_items[self.slot_light].id)
    def anim(self):
        self.plus_running=self.__direction[pygame.K_w]
        if self.count_for_anim[0]>0:
            self.count_for_anim[0]-=1
            self.player_rect.y-=1
        elif self.count_for_anim[0]==0 and self.count_for_anim[1]==0:
            self.count_for_anim[1]=10
        elif self.count_for_anim[1]>0:
            self.count_for_anim[1]-=1
            self.player_rect.y += 1
            if self.count_for_anim[1]==0:
                self.count_for_anim[0]=10
                self.player_rect.x=self.default[0]
                self.player_rect.y=self.default[1]
    def block_movement(self,huh):
        self.__direction[pygame.K_d]*=huh[0]
        self.__direction[pygame.K_a]*=huh[1]
        self.__direction[pygame.K_s]*=huh[2]
        self.__direction[pygame.K_w]*=huh[3]
    def move(self):
        self.imaginary_coords[0] += self.speed * (self.__direction[pygame.K_d]*self.blocking_movement[0] -
                                                  self.__direction[pygame.K_a]*self.blocking_movement[1]
                                                  )
        self.imaginary_coords[1] += self.speed * (self.__direction[pygame.K_s]*self.blocking_movement[2] - self.__direction[pygame.K_w]*
                                                  self.blocking_movement[3])
        if self.__direction[pygame.K_w]*self.blocking_movement[3]+self.__direction[pygame.K_s]*self.blocking_movement[2]==1:
            if self.__direction[pygame.K_a]\
            *self.blocking_movement[1]+self.__direction[pygame.K_d]*self.blocking_movement[0]==0:
                self.anim()
        else:
            self.head_spr_cnt=0
            self.count_for_anim[1]=1
            self.count_for_anim[0] = 0
        self.blocking_movement = [1, 1, 1, 1]
        if self.__direction[pygame.K_w]:
            self.facing = [False, False, False, False]
            self.facing[0] = True
            self.__counting+=1
        elif self.__direction[pygame.K_s]:
            self.facing = [False, False, False, False]
            self.facing[2]=True
            self.__counting += 1
        elif self.__direction[pygame.K_d]:
            self.facing = [False, False, False, False]
            self.facing[1]=True
            self.__counting += 1
        elif self.__direction[pygame.K_a]:
            self.facing=[False,False,False,False]
            self.facing[3]=True
            self.__counting += 1
        else:
            self.__counting=0
        self.__counting%=30
        """ИЗМЕНИТЬ ПОТОМ, ПОДСЧЕТ КАДРОВ ДЛЯ ИЗМЕНЕНИЯ СПРАЙТОВ"""
    def show_backpack(self,screen):
        if self.__count%4==0 and self.__count>0:
            self.__eq = not(self.__eq)
        if self.__count>0:
            self.__count -= 1
        screen.blit(self.__backpack_spr[1],[0,0])
        for i in range(self.backpack_slots):
            screen.blit(self.__backpack_spr[0], [100+130*(i%5),self.__y+(i//5*130)])
        for i in range(len(self.backpack_items)):
            if str(type(self.backpack_items[i]))=="<class 'ITEMS.heal_potion'>":
               self.backpack_items[i].draw(screen, [105 + 130 * (i % 5), self.__y+5 + (i // 5 * 130)])
            else:
                screen.blit(self.__test_img, [105 + 130 * (i % 5), self.__y+5 + (i // 5 * 130)])
        self.__backpack_rect.x = 100 + 130 * (self.slot_light % 5)
        self.__backpack_rect.y = self.__y + (self.slot_light // 5 * 130)
        pygame.draw.rect(screen, (76, 254, 115), self.__backpack_rect, 5)
        screen.blit(self.__icons[0],[105, 340])
        screen.blit(self.__icons[2], [105, 410])
        screen.blit(self.__icons[1], [105, 480])
        screen.blit(self.__backpack_spr[2], [self.__x*1.3, self.__y])
        screen.blit(self.__backpack_spr[3], [self.__x, self.__y])
        screen.blit(self.__buttons[self.__eq*1], self.__equip_rect)
        screen.blit(self.__icons[3], [self.coords[0]*2-200, 10])
        text1 = self.__font.render(str(self.money), True,
                          (255,255,255))
        screen.blit(text1,[self.coords[0]*2-125, 10])
    def backpack_append(self,j):
        if self.is_database_exists("PRoject2/DBS/BACKPACK/backpack.db"):
            with sqlite3.connect("PRoject2/DBS/BACKPACK/backpack.db") as connection:
                my_cursour=connection.cursor()
                text=str(j)
                query = f"INSERT INTO backpack(item) VALUES ('{text}')"
                my_cursour.execute(query)
                self.backpack_items=[]
                query = "SELECT * FROM backpack"
                my_cursour.execute(query)
                rows = my_cursour.fetchall()
                for i in rows:
                    self.backpack_items.append(i[1])
                print(self.backpack_items)
        else:
            print('БД не обнаружена')
    def collide(self):
        pass
    def hit_collide(self,a):
        return [False]
    def check(self):
        self.y_cord = self.player_rect.centery
    def draw_inventory(self,screen):
        if self.inventory:
            self.show_backpack(screen)
    """ОТРИСОВКА ИНВЕНТОРЯ"""
    def draw(self,screen):
        self.cooldown=self.cooldown//1.05
        screen.blit(self.__player_sprites[self.facing.index(True)][self.__counting//10],self.player_rect)
        self.slicing(screen)
        self.__show_xp(screen)
    def angle_shot(self):
        mouse=pygame.mouse.get_pos()
        dx = mouse[0] - self.__x
        dy = mouse[1] - self.__y
        rads = atan2(-dy, dx)
        rads %= 2 * pi
        degs = degrees(rads)
        degs=int(degs)
        self.cooldown=500
        cord=[1,1]
        if degs<=90:
            cord[0]=abs((90 - degs) / 45)
            cord[1]=abs(90 - (cord[0] * 45))
            cord[1]=round(cord[1]/90,4)*-1
            cord[0]=round(cord[0]/2,4)
        elif degs<=180:
            degs-=90
            cord[1] = abs((90 - degs) / 45)
            cord[0] = abs(90 - (cord[1] * 45))
            cord[0] = round(cord[0] / 90, 4)*-1
            cord[1] = round(cord[1] / 2, 4)*-1
        elif degs<=270:
            degs-=180
            cord[0] = abs((90 - degs) / 45)
            cord[1] = abs(90 - (cord[0] * 45))
            cord[1] = round(cord[1] / 90, 4)
            cord[0] = round(cord[0] / 2, 4)*-1
        else:
            degs-=270
            cord[1] = abs((90 - degs) / 45)
            cord[0] = abs(90 - (cord[1] * 45))
            cord[0] = round(cord[0] / 90, 4)
            cord[1] = round(cord[1] / 2, 4)
        return cord
    """УГОЛ ДЛЯ ВЫСТРЕЛА"""