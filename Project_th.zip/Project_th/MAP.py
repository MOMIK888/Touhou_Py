import random
import pygame
import save
class Enemy:
    def __init__(self, coords, player):
        self.__coords=coords
        self.__player = player
        self.__sprite = pygame.transform.smoothscale(
            pygame.image.load("PRoject2/cirno/tile038.png").convert_alpha(),
            (122, 120))
        self.__sleep_effect=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/EFFECT/sleep.png").convert_alpha(),
            (12, 12))
        """ЕФФЕКТ СНА"""
        self.spr_rect = self.__sprite.get_rect()
        self.spr_rect.x = self.__player.imaginary_coords[0] * -1 - self.__coords[0]
        self.spr_rect.y = self.__player.imaginary_coords[1] * -1 - self.__coords[1]
        self.__fps_count=0
        self.y_cord=self.spr_rect.centery
    def draw(self, screen):
        self.__fps_count+=1
        self.spr_rect.x = self.__player.imaginary_coords[0] * -1 - self.__coords[0]
        self.spr_rect.y = self.__player.imaginary_coords[1] * -1 - self.__coords[1]
        screen.blit(self.__sprite, self.spr_rect)
        self.__fps_count%=30
        self.effect()
        screen.blit(self.__sleep_effect, [self.spr_rect[0]+60,self.spr_rect[1]-self.__fps_count])
        self.y_cord = self.spr_rect.centery
    def effect(self):
        self.__sleep_effect.set_alpha(255-self.__fps_count*8.5)
    def check(self):
        pass
    def collide(self):
        pass
    def hit_collide(self, a):
        if pygame.Rect.colliderect(a, self.spr_rect):
            return [True, 'BOSS_BATTLE']
        else:
            return [False]


class SLIME:
    def __init__(self, coords, player):
        self.__coords=coords
        self.hp=1
        self.__player = player
        self.__sprite = pygame.transform.smoothscale(
            pygame.image.load("PRoject2/ENEMIES/slime.png").convert_alpha(),
            (128, 88))
        self.spr_rect = self.__sprite.get_rect()
        self.spr_rect.x = self.__player.imaginary_coords[0] * -1 - self.__coords[0]
        self.spr_rect.y = self.__player.imaginary_coords[1] * -1 - self.__coords[1]
        self.y_cord = self.spr_rect.bottom
        self.__y_plus=0
        self.__x_plus = 0
    def move(self):
        if self.spr_rect.centery<self.__player.player_rect.centery:
            self.__y_plus +=1
        elif self.spr_rect.centery>self.__player.player_rect.centery:
            self.__y_plus -=1
        if self.spr_rect.centerx>self.__player.player_rect.centerx:
            self.__x_plus -=1
        elif self.spr_rect.centerx<self.__player.player_rect.centerx:
            self.__x_plus +=1
    def draw(self, screen):
        self.spr_rect.x = self.__player.imaginary_coords[0] * -1 - self.__coords[0]+self.__x_plus
        self.spr_rect.y = self.__player.imaginary_coords[1] * -1 - self.__coords[1]+self.__y_plus
        screen.blit(self.__sprite,self.spr_rect)
        self.move()
    def check(self):
        pass
    def collide(self):
        pass
    def hit_collide(self,a):
        if pygame.Rect.colliderect(a, self.spr_rect):
            return [True, 'hit']
        else:
            return [False]


class WATER:
    def __init__(self, coords, player, render, size):
        self.__coords=coords
        self.__size=size
        self.player=player
        self.__render=render
        self.y_cord=1
        self.__sprite=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/MAP_OBJECTS/water_spr.png").convert(),
            (self.__size[0], self.__size[1]))
        self.spr_rect=self.__sprite.get_rect()
    def draw(self,screen):
        self.spr_rect.x=self.player.imaginary_coords[0]*-1-self.__coords[0]
        self.spr_rect.y=self.player.imaginary_coords[1]*-1-self.__coords[1]
        self.y_cord = self.player.imaginary_coords[1] * -1 - self.__coords[1]
        screen.blit(self.__sprite, self.spr_rect)
        if self.__render:
            self.check()
    def check(self):
        if pygame.Rect.colliderect(self.player.player_rect,self.spr_rect):
            if self.spr_rect.bottom-10<self.player.player_rect.top:
                self.player.blocking_movement[3] = 0
            elif self.spr_rect.top+10>self.player.player_rect.bottom:
                self.player.blocking_movement[2] = 0
            elif self.spr_rect.right-10>self.player.player_rect.left:
                self.player.blocking_movement[0] = 0
            elif self.spr_rect.left-10<self.player.player_rect.right:
                self.player.blocking_movement[1] = 0
    def return_center(self):
        return self.spr_rect.centery


class SAVEPOINT:
    def __init__(self, coords, player):
        self.__light = pygame.transform.smoothscale(
            pygame.image.load("PRoject2/EFFECT/lighting.bmp").convert_alpha(),
            (64,64))
        self.__spr=[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/MAP_OBJECTS/star1.png").convert_alpha(),
            (64,90)),pygame.transform.smoothscale(
            pygame.image.load("PRoject2/MAP_OBJECTS/star2.png").convert_alpha(),
            (64,90))]
        self.__light.set_colorkey((255, 255, 255))
        self.player = player
        self.spr_rect = self.__spr[0].get_rect()
        self.y_cord=1
        self.__frame=0
        self.count_for_anim=[5,0]
        self.__plus=0
        """КООРДИНАТА Y ДЛЯ"""
        self.coords = coords
        self.spr_rect_collide = pygame.Rect(64//2+self.player.imaginary_coords[0] * -1 - self.coords[0]-10,
                                     self.player.imaginary_coords[1] * -1 - self.coords[1] + 90//2-10, 20,30)
    def __anim(self):
        if self.count_for_anim[0] > 0:
            self.count_for_anim[0] -= 1
            self.__plus -= 0.7
        elif self.count_for_anim[0] == 0 and self.count_for_anim[1] == 0:
            self.count_for_anim[1] = 10
        elif self.count_for_anim[1] > 0:
            self.count_for_anim[1] -= 1
            self.__plus += 0.7
            if self.count_for_anim[1] == 0:
                self.count_for_anim[0] = 10
    def hit_collide(self,a):
        if pygame.Rect.colliderect(a, self.spr_rect_collide):
            return [True, 'save']
        else:
            return [False]
    def check(self):
        self.y_cord = self.spr_rect_collide.bottom
    def draw(self, screen):
        if self.__frame%3==0:
            self.__anim()
            self.__frame=self.__frame%3
        self.__frame+=1
        self.spr_rect_collide.x, self.spr_rect_collide.y= 64// 2 + self.player.imaginary_coords[0] * -1 - self.coords[0] - 10, \
            self.player.imaginary_coords[1] * -1 - self.coords[1] + 90 // 2 - 10
        self.spr_rect.x = self.player.imaginary_coords[0] * -1 - self.coords[0]
        self.spr_rect.y = self.player.imaginary_coords[1] * -1 - self.coords[1]
        for i in range(len(self.__spr)):
            screen.blit(self.__spr[i], [self.spr_rect[0], self.spr_rect[1]+self.__plus*i])
    def collide(self):
        if pygame.Rect.colliderect(self.player.player_rect,self.spr_rect_collide):
            if self.spr_rect_collide.bottom-10<self.player.player_rect.top:
                self.player.blocking_movement[3] = 0
            elif self.spr_rect_collide.top+10>self.player.player_rect.bottom:
                self.player.blocking_movement[2] = 0
            elif self.spr_rect_collide.right-10>self.player.player_rect.left:
                self.player.blocking_movement[0] = 0
            elif self.spr_rect_collide.left-10<self.player.player_rect.right:
                self.player.blocking_movement[1] = 0


class Tree:
    def __init__(self, coords, player, tree_type, size, sprite='default', fliping='default'):
        self.coords=coords
        self.player = player
        self.__tree_type=tree_type
        self.__sprite=sprite
        if self.__sprite=='default':
            self.__sprite=random.randint(0,3)
        self.__size=size
        if self.__sprite==0:
            self.__sprite=pygame.transform.smoothscale(
            pygame.image.load("PRoject2/Tree/Tree_blue.png").convert_alpha(),
            (self.__size[0], self.__size[1]))
        elif self.__sprite==1:
            self.__sprite =pygame.transform.smoothscale(
            pygame.image.load("PRoject2/Tree/Tree_pink.png").convert_alpha(),
            (self.__size[0], self.__size[1]))
        elif self.__sprite==2:
            self.__sprite =pygame.transform.smoothscale(
            pygame.image.load("PRoject2/Tree/Tree_orange.png").convert_alpha(),
            (self.__size[0], self.__size[1]))
        else:
            self.__sprite = pygame.transform.smoothscale(
            pygame.image.load("PRoject2/Tree/Tree_purple.png").convert_alpha(),
            (self.__size[0], self.__size[1]))
        self.flip=fliping
        if self.flip=='default':
            self.flip=random.randint(0,2)
        self.plus=0
        if self.flip==1:
            self.__sprite=pygame.transform.flip(self.__sprite,True, False)
            self.plus=36
        self.spr_rect=self.__sprite.get_rect()
        self.colliderect=pygame.Rect(self.__size[0]//3+self.player.imaginary_coords[0] * -1 - self.coords[0],
                                     self.player.imaginary_coords[1] * -1 - self.coords[1] + self.__size[1]//4*3, 40,25)
        self.y_cord = self.player.imaginary_coords[1] * -1 - self.coords[1]
    def check(self):
        self.y_cord = self.colliderect.bottom
    def draw(self, screen):
        self.colliderect.x=self.__size[0]//2.3+self.plus+self.player.imaginary_coords[0] * -1 - self.coords[0]
        self.colliderect.y=self.__size[1]//4*2.7+30+self.player.imaginary_coords[1] * -1 - self.coords[1]
        self.spr_rect.x = self.player.imaginary_coords[0] * -1 - self.coords[0]
        self.spr_rect.y = self.player.imaginary_coords[1] * -1 - self.coords[1]
        screen.blit(self.__sprite, self.spr_rect)
    def return_center(self):
        return self.spr_rect.centery
    def collide(self):
        if pygame.Rect.colliderect(self.player.player_rect,self.colliderect):
            if self.colliderect.bottom-10<self.player.player_rect.top:
                self.player.blocking_movement[3] = 0
            elif self.colliderect.top+10>self.player.player_rect.bottom:
                self.player.blocking_movement[2] = 0
            elif self.colliderect.right-10>self.player.player_rect.left:
                self.player.blocking_movement[0] = 0
            elif self.colliderect.left-10<self.player.player_rect.right:
                self.player.blocking_movement[1] = 0
    def hit_collide(self,rect):
        if pygame.Rect.colliderect(rect, self.colliderect):
            print('aaaaaaa')
            return [True,'wood']
        else:
            return [False]


class map:
    def __init__(self,w,h,player,bullets):
        self.imagination_coords=[[1500,1500]]
        self.maps=[pygame.transform.smoothscale(
            pygame.image.load("PRoject2/bg.jpg").convert(),
            (3600, 3600))]
        self.enemy_cords=[[1200,1200]]
        self.map_cnts=0
        self.bullets=bullets
        self.player=player
        self.map_objects_water=[[WATER([-1200, -1200], player,True, (512,512))]]
        self.map_objects=[[Tree([-1500, -1400], player,0,[512,512]),Tree([-1500, -1700], player,0,[512,512]),
                             Tree([-1800, -1500], player,0,[512,512]), SAVEPOINT([-2000, -1950],self.player),
                           SAVEPOINT([-1800, -1800],self.player),Enemy([-2300, -2000],self.player)]]
        for i in range(len(self.map_objects)):
            self.map_objects[i]=sorted(self.map_objects[i],key=lambda student: student.y_cord)
        print(self.map_objects)
    def change_pos(self):
        self.player.imaginary_coords=self.imagination_coords[self.map_cnts]
    def draw(self,screen):
        pass
